package com.example.demo.domain.product.service;

import com.example.demo.domain.product.dto.ProductDTO;

import java.util.List;

public interface ProductService {
    List<ProductDTO> getAllProducts();
}
